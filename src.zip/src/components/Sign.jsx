import React, { useState } from 'react';
import './sign.css';

const Sign = () => {
    const [formData, setFormData] = useState({
        email: '',
        password: '',
        confirmPassword: '',
    });

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();

        // Validation du format de l'email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData.email)) {
            alert('Veuillez saisir une adresse e-mail valide.');
            return;
        }

        // Validation de la correspondance des mots de passe
        if (formData.password !== formData.confirmPassword) {
            alert('Les mots de passe ne correspondent pas.');
            return;
        }

        // Ajoutez ici la logique de création de compte ou utilisez un état pour gérer les valeurs du formulaire
        console.log('Formulaire soumis avec succès', formData);
    };

    return (
        <div className="form-container">
            <form className="sign-form" onSubmit={handleSubmit}>
                <div className="group">
                    <label htmlFor="email">Mail</label>
                    <input
                        type="text"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                    />
                </div>
                <div className="group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                    />
                </div>
                <div className="group">
                    <label htmlFor="confirmPassword">Confirm Password</label>
                    <input
                        type="password"
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                    />
                </div>
                <div className="group">
                    <button type="submit">Create</button>
                </div>
            </form>
        </div>
    );
};

export default Sign;
