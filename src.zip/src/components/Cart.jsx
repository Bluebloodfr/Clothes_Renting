import React from 'react';
import './cart.css';  // Importer le fichier CSS pour ce composant

const Cart = ({ cart }) => {
    const calculateTotal = () => {
        return cart.reduce((total, product) => total + product.price, 0);
    };

    return (
        <div className="cart-container">
            <h2>Panier</h2>
            <div className="cart-items">
                {cart.map((product) => (
                    <div key={product.id} className="cart-item">
                        <img src={product.image} alt={product.name} />
                        <div className="item-details">
                            <p className="item-name">{product.name}</p>
                            <p className="item-price">${product.price}</p>
                        </div>
                    </div>
                ))}
            </div>
            <div className="cart-total">
                <p>Total: ${calculateTotal()}</p>
                <button>Payer</button>
            </div>
        </div>
    );
};

export default Cart;
