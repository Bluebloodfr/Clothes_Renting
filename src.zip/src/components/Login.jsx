// Login.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import './login.css';

const Login = () => {
    return (
        <div className="login-container">
            <form className="login-form">
                <div className="group">
                    <label htmlFor="login">Mail</label>
                    <input type="text" name="login" />
                </div>
                <div className="group">
                    <label htmlFor="password">Password</label>
                    <input type="password" name="password" />
                </div>
                <div className="group">
                    <button type="submit">Connexion</button>
                </div>
            </form>

            {/* Ajout du bouton "Sign Up" */}
            <div className="signup-link">
                <p>Vous n'avez pas de compte ?</p>
                <Link to="/sign">
                    <button>Sign Up</button>
                </Link>
            </div>
        </div>
    );
};

export default Login;
