// Product.jsx
import React, { useState } from 'react';
import './product.css';  
import { Link } from 'react-router-dom';

const Product = ({ addToCart: addToCartProp }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [products, setProducts] = useState([
        { id: 1, name: 'Article 1', price: 20, image: 'url_de_l_image_1.jpg' },
        { id: 2, name: 'Article 2', price: 30, image: 'url_de_l_image_2.jpg' },
        { id: 3, name: 'Article 3', price: 25, image: 'url_de_l_image_3.jpg' },
        // Ajoutez d'autres articles avec des images et des détails
    ]);
    const [cart, setCart] = useState([]);

    const handleSearch = (e) => {
        setSearchTerm(e.target.value);
    };

    const handleAddToCart = (productId) => {
        const selectedProduct = products.find(product => product.id === productId);
        setCart([...cart, selectedProduct]);
        addToCartProp(productId);  // Appeler la fonction de la prop avec l'ID du produit
    };

    const filteredProducts = products.filter((product) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="product-container">
            <h2>Page de vente</h2>
            <div className="search-bar">
                <input
                    type="text"
                    placeholder="Rechercher des articles..."
                    value={searchTerm}
                    onChange={handleSearch}
                />
            </div>
            <div className="product-grid">
                {filteredProducts.map((product) => (
                    <div key={product.id} className="product-item">
                        <img src={product.image} alt={product.name} />
                        <div className="product-details">
                            <p className="product-name">{product.name}</p>
                            <p className="product-price">${product.price}</p>
                            <button onClick={() => handleAddToCart(product.id)}>Ajouter au panier</button>
                        </div>
                    </div>
                ))}
            </div>
            <div className="my-cart-button">
                <Link to="/cart">
                    <button>My Cart</button>
                </Link>
            </div>
        </div>
    );
};

export default Product;
