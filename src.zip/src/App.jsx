// App.jsx
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Login from './components/Login';
import Sign from './components/Sign';
import Product from './components/Product';
import Cart from './components/Cart';

const App = () => {
    const [cart, setCart] = useState([]);

    const addToCart = (productId) => {
        // Ajoutez le produit au panier comme vous le faites actuellement
        const productToAdd = {
            id: productId,
            name: `Article ${productId}`,
            price: Math.floor(Math.random() * 50) + 1,
            image: 'url_de_l_image.jpg',
        };

        // Mettez à jour l'état du panier
        setCart([...cart, productToAdd]);
    };

    return (
        <Router>
            <div>
                <Routes>
                    {/* Passez la fonction addToCart et l'état du panier au composant Product */}
                    <Route path="/product" element={<Product addToCart={addToCart} />} />
                    <Route path="/cart" element={<Cart cart={cart} />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/sign" element={<Sign />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
